<?php

include ("../connexion.php");

$card1 = $pdo->prepare("SELECT * FROM offres INNER JOIN entreprises ON offres.ID_Entreprise = entreprises.ID_Entreprise INNER JOIN type_contrat ON offres.ID_Type_contrat = type_contrat.ID_Type_contrat WHERE ID_Offre =" . $_GET["id"] . "");
$card1->execute();
$response1 = $card1->fetch(PDO::FETCH_NUM);

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="recherche.css"/>

        <!-- Boostrap -->
        <link rel="stylesheet" href="../assets/vendors/bootstrap/bootstrap-4.5.3-dist/css/bootstrap.min.css" />

        <!-- FontAwesome -->
        <link rel="stylesheet" href="../assets/vendors/fontawesome/css/all.min.css" />
        
        <!-- BoostrapIcon -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css">

    </head>
    <body>
    <div>
        <h1><?= htmlentities($response1[10]); ?></h1>
        <p class="h4">Offre crée par <?= htmlentities($response1[15]); ?></p>
        <p class="h5">Description de l'offre :</p>
        <p><?= htmlentities($response1[7]); ?>.</p>
        <p>Les compétences requises pour ce poste sont : <b><?= htmlentities($response1[6]); ?></b>. L'entreprise <?= htmlentities($response1[15]); ?> est à la recherche de <b><?= htmlentities($response1[5]); ?></b> personne(s) pour une durée de <b><?= htmlentities($response1[2]); ?></b> mois.</p>
        
        <div>
            <!-- Bouton postuler -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                Postuler
            </button>
              
              <!-- Modal -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLongTitle">Postuler</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                        <form>
                            <h5>CV : </h5><input type="file" name="cv" accept="application/pdf">
                            <br/>
                            <h5>Lettre de motivation : </h5><input type="file" name="lm" accept=".pdf">
                            <br/>
                        </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                      <button type="button" class="btn btn-primary">Envoyer</button>
                    </div>
                  </div>
                </div>
            </div>

            <!-- Bouton WishList -->
            <button type="button" class="btn btn-primary">
                <i class="bi bi-heart"></i>
            </button>
              
        </div>
      </div>
        <!-- JQuery -->
  		 <script src="../assets/vendors/jquery/jquery-3.5.1.min.js"></script>
		 <!-- Bootstrap -->
		 <script src="../assets/vendors/bootstrap/bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"></script>  

		 <!-- FontAwesome -->
		 <script src="../https://kit.fontawesome.com/fc47d2f2d9.js" crossorigin="anonymous"></script>
    </body>
</html>