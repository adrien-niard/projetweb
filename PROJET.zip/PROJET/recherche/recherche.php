<?php
include ("../connexion.php");

$query = $pdo->prepare("SELECT COUNT(ID_Offre) FROM offres");
$query->execute();
$result = $query->fetch(PDO::FETCH_NUM);

$j = 0;
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8" />
		<link rel="stylesheet" type="text/css" href="recherche.css"/>

		<!-- Bootstrap -->
		<link rel="stylesheet" href="../assets/vendors/bootstrap/bootstrap-4.5.3-dist/css/bootstrap.min.css" />

		
		<!-- FontAwesome -->
		<link rel="stylesheet" href="../assets/vendors/fontawesome/css/all.min.css" />

		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Recherche entreprise
		</title>
	</head>
	<body style="overflow-x: hidden;">
    <!-- Header + Image + Bouton -->
    <header class="blog-header py-3 bg-dark">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <div class="col-4 pt-1">
                <!-- Logo CESI -->
                <img src="../images/cesi.png" class="cesi" alt="Logo CESI Ton Stage" style="margin-left: 20px;"/>
            </div>
            <div class="col-4 text-center">
                <!-- Titre de l'accueil : CESI ton stage -->
                <a class="blog-header-title text-light" href="../accueil/accueil.html">CESI ton stage</a>
            </div>
            <div class="col-4 d-flex justify-content-end align-items-center">
                <!-- Bouton Pannel de contrôle -->
                <a class="btn btn-md btn-outline-secondary" href="../panneau_de_gestion/panneau.html" style="margin: 0 20px 8px 0; color: white;">Pannel de contrôle</a>
            </div>
        </div>
    </header>
    <!-- Barre recherche-->
		<form action="" method="POST">
			<fieldset class="form-group border p-3 d-flex justify-content-between">
				<div class="custom-line d-flex flex-column col-lg-2">
					<div>
						<!--Spécialité-->
						<div>
							<select id="specialite" class="btn btn-secondary w-100 mb-1" name="specialite">
								<option value="specialite" selected>Spécialité</option>
								<option value="informatique">Informatique</option>
								<option value="btp">BTP</option>
								<option value="generaliste">Généraliste</option>
								<option value="s3e">S3E</option>
							</select>
						</div>
						<!--Promotion-->
						<div>
							<select class="btn btn-secondary w-100" name="promotion">
								<option value="promotion" selected>Promotion</option>
								<option value="cpi_a1">CPI A1</option>
								<option value="cpi_a2">CPI A2</option>
								<option value="ci_a3">CI A3</option> 
								<option value="ci_a4">CI A4</option>
								<option value="ci_a5">CI A5</option>
							</select>
						</div>
					</div>

					<div class="">
						<!--Durée stage-->
						<div class="text_p">
							<input type="text" class="w-100" placeholder="Durée du stage (en mois)">
						</div>

						<!--Poste recherché-->
						<div class="text_p">
							<input type="text" class="w-100" placeholder="Poste recherche">
						</div>

						<!--Lieu-->
						<div class="text_p">
							<input type="text" class="w-100" placeholder="Lieu">
						</div>
					</div>
					

					<div>
						<!--Boutons-->
						<div class="btn_p">
							<input class="submit w-100" type="submit" value="Rechercher">
						</div>
						<div class="btn_p">
							<input class="reset w-100" type="reset" value="Rénitialiser la recherche">
						</div>
					</div>
						<div class="contain">
							<h5>Choix entreprises</h5>
							<div class="dropdown-divider"></div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">Entreprise 1</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
								<label class="form-check-label" for="defaultCheck2">Entreprise 2</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck3">
								<label class="form-check-label" for="defaultCheck3">Entreprise 3</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck4">
								<label class="form-check-label" for="defaultCheck4">Entreprise 4</label>
							</div>
						</div>

						<div class="contain">
							<h5>Choix compétences</h5>
							<div class="dropdown-divider"></div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">C</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">C++</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">Python</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">Réseau</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">HTML</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">CSS</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">JavaScript</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">PHP</label>
							</div>
							<div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
								<label class="form-check-label" for="defaultCheck1">SQL</label>
							</div>
						</div>
				</div>
				<div class="d-flex flex-column">
				<?php for ($i=1;$i<=$result[0];$i++) { 
					$j += 1; 
				?>
				
				<?php 
				$card = $pdo->prepare("SELECT * FROM offres INNER JOIN entreprises ON offres.ID_Entreprise = entreprises.ID_Entreprise INNER JOIN type_contrat ON offres.ID_Type_contrat = type_contrat.ID_Type_contrat WHERE ID_Offre =" . $j . "");
				$card->execute();
				$response = $card->fetch(PDO::FETCH_NUM);
				?>

					<?php if ($response != false) { ?>
						<div class="d-flex flex-column col-lg-2" style="border:inherit;">
							<div class="card card_id" id="<?= htmlentities($response[0]); ?>" link="random" style="width: 18rem;">
								<div class="card-body">
								<h5 class="card-title">Intitulé : <?= htmlentities($response[10]); ?></h5>
								<h6 class="card-subtitle mb-2 text-muted">Entreprise : <?= htmlentities($response[15]); ?></h6>
								<p class="card-text">Date : <?= htmlentities($response[4]); ?></p>
								</div>
							</div>
						</div>
					<?php } else { $i--;}} ?>
				</div>
				
				<div class="col-lg-8" style="border: inherit;">
					<iframe id="iframe-offre" width=100% height=100% src=""></iframe>
				</div>
			</fieldset>
		</form>
		<footer class="bg-dark text-center text-white">
			<div class=" p-4 pb-0 d-flex justify-content-around">
				<div class="mb-4 pr-auto col-lg-4">
					<h4>Nous contacter :</h4>
					<p>AdresseMail@fake.fr</p>
					<p>69 Rue de l'Adresse Cassée</p>
				</div>
				<section class="mb-4 d-flex align-self-center col-lg-4" style="padding-left: 13%;">
					<!-- Facebook -->
					<a class="btn btn-outline-light btn-floating m-1" href="https://fr-fr.facebook.com/CesiCampusRouen/" target="_blank" role="button">
						<i class="fab fa-facebook-f"></i>
					</a>
					
					<!-- Twitter -->
					<a class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/GroupeCESI?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank" role="button">
						<i class="fab fa-twitter"></i>
					</a>

					<!-- Instagram -->
					<a class="btn btn-outline-light btn-floating m-1" href="https://www.instagram.com/campus_cesi/?hl=fr" target="_blank" role="button">
						<i class="fab fa-instagram"></i>
					</a>
				</section>
				<div class="mb-4 pl-auto col-lg-4">
					<h4>Mentions légales :</h4>
					<p>...</p>
				</div>
			</div>
          
			<!-- Copyright -->
			<div class="text-center p-2" style="background-color: rgba(0, 0, 0, 0.2);">
			  © 2021 Copyright:
			  <a class="text-white" href="https://cesi.fr">CESI</a>
			</div>
		</footer>

		 <!-- JQuery -->
		 <script src="../assets/vendors/jquery/jquery-3.5.1.min.js"></script>

		 <!-- Bootstrap -->
		 <script src="../assets/vendors/bootstrap/bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"></script>  

		
		 <!-- FontAwesome -->
		 <script src="../https://kit.fontawesome.com/fc47d2f2d9.js" crossorigin="anonymous"></script>

		<script>
			$iframe = document.getElementById("iframe-offre");

			$(".card_id").click(function RedirectionJavascript(){
				$lien = this.getAttribute("link");
				$id = this.getAttribute("id");
				$iframe.setAttribute("src", $lien + ".php?id=" + $id); 


				window.location.replace = "http://localhost/website/PROJET/recherche/recherche.php?id=" + $id;

				$("#iframe-offre").load($lien + ".php?id=" + $id);
			})
		</script>
	</body>
</html>