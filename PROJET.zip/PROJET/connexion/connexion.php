<?php
	try{
		$DB_host = "localhost";
	    $DB_user = "root";
	    $DB_pass = "";
	    $DB_name = "cesi_ton_stage";

		$pdo=new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
?>