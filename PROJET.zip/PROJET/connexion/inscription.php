<?php
	include("connexion.php");

	// Data à envoyer dans la bdd (récupéré dans le form)
	@$nom=$_POST["Nom"];
	@$prenom=$_POST["Prénom"];
	@$login=$_POST["email"];
	@$pass=$_POST["Password"];
	@$repass=$_POST["repass"];
	@$valider=$_POST["valider"];
	@$centre=$_POST["centre_list"];
	@$promo=$_POST["promo_list"];
	// Permissions
	@$SFx2=$_POST["SFx2"];
	@$SFx3=$_POST["SFx3"];
	@$SFx4=$_POST["SFx4"];
	@$SFx5=$_POST["SFx5"];
	@$SFx6=$_POST["SFx6"];
	@$SFx7=$_POST["SFx7"];
	@$SFx8=$_POST["SFx8"];
	@$SFx9=$_POST["SFx9"];
	@$SFx10=$_POST["SFx10"];
	@$SFx11=$_POST["SFx11"];
	@$SFx12=$_POST["SFx12"];
	@$SFx13=$_POST["SFx13"];
	@$SFx14=$_POST["SFx14"];
	@$SFx15=$_POST["SFx15"];
	@$SFx16=$_POST["SFx16"];
	@$SFx17=$_POST["SFx17"];
	@$SFx18=$_POST["SFx18"];
	@$SFx19=$_POST["SFx19"];
	@$SFx20=$_POST["SFx20"];
	@$SFx22=$_POST["SFx22"];
	@$SFx23=$_POST["SFx23"];
	@$SFx24=$_POST["SFx24"];
	@$SFx25=$_POST["SFx25"];
	@$SFx26=$_POST["SFx26"];
	@$SFx32=$_POST["SFx32"];
	@$SFx33=$_POST["SFx33"];

	$message="";

	// Listes déroulantes (centres et promotions)
	// Centres
	$smt_centre = $pdo->prepare('SELECT Centre FROM centres');
	$smt_centre->execute();
	@$data_centre = $smt_centre->fetchAll();
	// Promotions
	$smt_prom = $pdo->prepare('SELECT Nom FROM promotions');
	$smt_prom->execute();
	@$data_prom = $smt_prom->fetchAll();

	// Insertions dans la bdd
	if(isset($valider)){
		if(empty($nom)) $message="<li>Nom invalide !</li>";
		if(empty($prenom)) $message.="<li>Prénom invalide !</li>";
		if(empty($login)) $message.="<li>Identifiant invalide !</li>";
		if(empty($pass)) $message.="<li>Mot de passe invalide !</li>";
		if($pass!=$repass) $message.="<li>Mots de passe non identiques !</li>";

		if(empty($message)){
			$req=$pdo->prepare("SELECT ID_User FROM users WHERE Login=? LIMIT 1");
			$req->setFetchMode(PDO::FETCH_ASSOC);
			$req->execute(array($login));
			$tab=$req->fetchAll();

			if(count($tab)>0){
				$message="<li>Identifiant déjà utilisé !</li>";

			}else{
				$selection = $_POST['type_compte_r'];

				if ($selection == "etudiant_r") {
					$ins_in_users=$pdo->prepare("INSERT INTO users(Login,Password,Nom,Prénom,ID_Centre,ID_Promotion,User_Visible) 
					VALUES(?,?,?,?,(SELECT ID_Centre FROM centres WHERE Centre = '$centre'),(SELECT ID_Promotion FROM promotions WHERE Nom = '$promo'),1)");
					$ins_in_users->execute(array($login,md5($pass),$nom,$prenom));
					$up_in_users=$pdo->query("UPDATE users SET ID_WishList = MAX(ID_User) WHERE ID_User = MAX(ID_User)");

					$ins_in_rôles=$pdo->query("INSERT INTO rôles(ID_User,User) VALUES((SELECT MAX(ID_User) FROM users),1)");

					//echo $centre;
					header("location:index.php");

				}elseif ($selection == "delegue_r") {
					$ins_in_users=$pdo->prepare("INSERT INTO users(Login,Password,Nom,Prénom,ID_Centre,ID_Promotion,User_Visible) 
					VALUES(?,?,?,?,(SELECT ID_Centre FROM centres WHERE Centre = '$centre'),(SELECT ID_Promotion FROM promotions WHERE Nom = '$promo'),1)");
					$ins_in_users->execute(array($login,md5($pass),$nom,$prenom));
					$up_in_users=$pdo->query("UPDATE users SET ID_WishList = MAX(ID_User) WHERE ID_User = MAX(ID_User)");

					$ins_in_rôles=$pdo->query("INSERT INTO rôles(ID_User,User) VALUES((SELECT MAX(ID_User) FROM users),1)");
					$ins_in_delegue_0=$pdo->query("INSERT INTO délégué(ID_User) VALUES((SELECT ID_User FROM users ORDER BY ID_User DESC LIMIT 1))");

					// checkbox
					if ($SFx2 == 1) {$ins_in_delegue_1=$pdo->query("UPDATE délégué SET SFx2 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx3 == 1) {$ins_in_delegue_2=$pdo->query("UPDATE délégué SET SFx3 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx4 == 1) {$ins_in_delegue_3=$pdo->query("UPDATE délégué SET SFx4 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx5 == 1) {$ins_in_delegue_4=$pdo->query("UPDATE délégué SET SFx5 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx6 == 1) {$ins_in_delegue_5=$pdo->query("UPDATE délégué SET SFx6 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx7 == 1) {$ins_in_delegue_6=$pdo->query("UPDATE délégué SET SFx7 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx8 == 1) {$ins_in_delegue_7=$pdo->query("UPDATE délégué SET SFx8 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx9 == 1) {$ins_in_delegue_8=$pdo->query("UPDATE délégué SET SFx9 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx10 == 1) {$ins_in_delegue_9=$pdo->query("UPDATE délégué SET SFx10 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx11 == 1) {$ins_in_delegue_10=$pdo->query("UPDATE délégué SET SFx11 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx12 == 1) {$ins_in_delegue_11=$pdo->query("UPDATE délégué SET SFx12 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx13 == 1) {$ins_in_delegue_12=$pdo->query("UPDATE délégué SET SFx13 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx14 == 1) {$ins_in_delegue_13=$pdo->query("UPDATE délégué SET SFx14 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx15 == 1) {$ins_in_delegue_14=$pdo->query("UPDATE délégué SET SFx15 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx16 == 1) {$ins_in_delegue_15=$pdo->query("UPDATE délégué SET SFx16 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx17 == 1) {$ins_in_delegue_16=$pdo->query("UPDATE délégué SET SFx17 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx18 == 1) {$ins_in_delegue_17=$pdo->query("UPDATE délégué SET SFx18 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx19 == 1) {$ins_in_delegue_18=$pdo->query("UPDATE délégué SET SFx19 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx20 == 1) {$ins_in_delegue_19=$pdo->query("UPDATE délégué SET SFx20 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx22 == 1) {$ins_in_delegue_20=$pdo->query("UPDATE délégué SET SFx22 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx23 == 1) {$ins_in_delegue_21=$pdo->query("UPDATE délégué SET SFx23 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx24 == 1) {$ins_in_delegue_22=$pdo->query("UPDATE délégué SET SFx24 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx25 == 1) {$ins_in_delegue_23=$pdo->query("UPDATE délégué SET SFx25 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx26 == 1) {$ins_in_delegue_24=$pdo->query("UPDATE délégué SET SFx26 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx32 == 1) {$ins_in_delegue_25=$pdo->query("UPDATE délégué SET SFx32 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}
					if ($SFx33 == 1) {$ins_in_delegue_26=$pdo->query("UPDATE délégué SET SFx33 = 1 WHERE ID_User = (SELECT MAX(ID_User) FROM délégué)");}

					//echo $centre;
					header("location:index.php");

				}elseif ($selection == "pilote_r") {
					$ins_in_users=$pdo->prepare("INSERT INTO users(Login,Password,Nom,Prénom,ID_Centre,ID_Promotion,User_Visible) 
					VALUES(?,?,?,?,(SELECT ID_Centre FROM centres WHERE Centre = '$centre'),(SELECT ID_Promotion FROM promotions WHERE Nom = '$promo'),1)");
					$ins_in_users->execute(array($login,md5($pass),$nom,$prenom));
					$up_in_users=$pdo->query("UPDATE users SET ID_WishList = MAX(ID_User) WHERE ID_User = MAX(ID_User)");
					
					$ins_in_rôles=$pdo->query("INSERT INTO rôles(ID_User,Pilote) VALUES((SELECT MAX(ID_User) FROM users),1)");

					//echo $centre;
					header("location:index.php");

				}else{
					echo "Erreur, aucun type de compte sélectionné.";
				}
			}
		}
	}
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<link rel="stylesheet" type="text/css" href="css/style_inscription.css" />
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="theme-color" content="#FFFF"/>
		<link rel="manifest" href="manifest.json">
		<title>Création de compte</title>
	</head>
	<body>
		<header>
			<div id="top_title">
				<img class="img-valign" src="assets/img/cesi.png" height="80" alt="logo" />
				<span id="cesi">CESI</span><span id="ts"> ton stage!</span>
			</div>
		</header>
		<main>
			<div id="form_ins">
				<form name="fo" method="post" action="" enctype="multipart/form-data">
					<p id="f_p">Créer un compte</p>
					<div class="label">Type de compte :</div>
						<div id="type_compte">
							<label>Étudiant
								<input type="radio" name="type_compte_r" value="etudiant_r" id="choix1" onclick="showRadio()"></label>
							<label>Délégué
								<input type="radio" name="type_compte_r" value="delegue_r" id="choix2" onclick="showRadio()"></label>
							<label>Pilote
								<input type="radio" name="type_compte_r" value="pilote_r" id="choix3" onclick="showRadio()"></label>
						</div>
					<div id="test">
						<label class="label">Nom :
							<input type="text" name="Nom" value="<?php echo $nom?>"/></label>
						<label class="label">Prénom :
							<input type="text" name="Prénom" value="<?php echo $prenom?>"/></label>
						<label class="label">Mot de passe :
							<input type="password" name="Password"/></label>
						<label class="label">Confirmation du mot de passe :
							<input type="password" name="repass"/></label>
						<label class="label">Adresse e-mail :
							<input type="email" name="email"/></label>
					</div>

					<div id="D2"><!-- délégué -->
						<label class="label">Centre :
							<select name="centre_list" class="centre_list">
								<?php foreach ($data_centre as $row): ?>
								    <option><?=$row["Centre"]?></option>
								<?php endforeach ?>
							</select></label>
						<label class="label">Promotion assignée :
							<select name="promo_list" class="promo_list">
								<?php foreach ($data_prom as $row): ?>
								    <option><?=$row["Nom"]?></option>
								<?php endforeach ?>
							</select></label>
						<!-- multiselect -->
						<div class="multiselect">
						    <div class="selectBox" onclick="showCheckboxes()">
						      <select>
						        <option>Attribuer des permissions</option>
						      </select>
						      <div class="overSelect"></div>
						    </div>
						    <!-- permissions -->
						    <div id="checkboxes">
						      <label for="SFx2">
						        <input type="checkbox" name="SFx2" class="SFx2" value="1"/>Rechercher une entreprise</label>
						      <label for="SFx3">
						        <input type="checkbox" name="SFx3" class="SFx3" value="1"/>Créer une entreprise</label>
						      <label for="SFx4">
						        <input type="checkbox" name="SFx4" class="SFx4" value="1"/>Modifier une entreprise</label>
						      <label for="SFx5">
						        <input type="checkbox" name="SFx5" class="SFx5" value="1"/>Évaluer une entreprise</label>
						      <label for="SFx6">
						        <input type="checkbox" name="SFx6" class="SFx6" value="1"/>Supprimer une entreprise</label>
						      <label for="SFx7">
						        <input type="checkbox" name="SFx7" class="SFx7" value="1"/>Consulter les stats des entreprises</label>
						      <label for="SFx8">
						        <input type="checkbox" name="SFx8" class="SFx8" value="1"/>Rechercher une offre</label>
						      <label for="SFx9">
						        <input type="checkbox" name="SFx9" class="SFx9" value="1"/>Créer une offre</label>
						      <label for="SFx10">
						        <input type="checkbox" name="SFx10" class="SFx10" value="1"/>Modifier une offre</label>
						      <label for="SFx11">
						        <input type="checkbox" name="SFx11" class="SFx11" value="1"/>Supprimer une offre</label>
						      <label for="SFx12">
						        <input type="checkbox" name="SFx12" class="SFx12" value="1"/>Consulter les stats des offres</label>
						      <label for="SFx13">
						        <input type="checkbox" name="SFx13" class="SFx13" value="1"/>Rechercher un compte pilote</label>
						      <label for="SFx14">
						        <input type="checkbox" name="SFx14" class="SFx14" value="1"/>Créer un compte pilote</label>
						      <label for="SFx15">
						        <input type="checkbox" name="SFx15" class="SFx15" value="1"/>Modifier un compte pilote</label>
						      <label for="SFx16">
						        <input type="checkbox" name="SFx16" class="SFx16" value="1"/>Supprimer un compte pilote</label>
						      <label for="SFx17">
						        <input type="checkbox" name="SFx17" class="SFx17" value="1"/>Rechercher un compte délégué</label>
						      <label for="SFx18">
						        <input type="checkbox" name="SFx18" class="SFx18" value="1"/>Créer un compte délégué</label>
						      <label for="SFx19">
						        <input type="checkbox" name="SFx19" class="SFx19" value="1"/>Modifier un compte délégué</label>
						      <label for="SFx20">
						        <input type="checkbox" name="SFx20" class="SFx20" value="1"/>Supprimer un compte délégué</label>
						      <label for="SFx22">
						        <input type="checkbox" name="SFx22" class="SFx22" value="1"/>Rechercher un compte étudiant</label>
						      <label for="SFx23">
						        <input type="checkbox" name="SFx23" class="SFx23" value="1"/>Créer un compte étudiant</label>
						      <label for="SFx24">
						        <input type="checkbox" name="SFx24" class="SFx24" value="1"/>Modifier un compte étudiant</label>
						      <label for="SFx25">
						        <input type="checkbox" name="SFx25" class="SFx25" value="1"/>Supprimer un compte étudiant</label>
						      <label for="SFx26">
						        <input type="checkbox" name="SFx26" class="SFx26" value="1"/>Consulter les stats des étudiant</label>
						      <label for="SFx32">
						        <input type="checkbox" name="SFx32" class="SFx32" value="1"/>Informer le système de l'avancement de la candidature step 3</label>
						      <label for="SFx33">
						        <input type="checkbox" name="SFx33" class="SFx33" value="1"/>Informer le système de l'avancement de la candidature step 4</label>
						    </div>
					  	</div>
					</div>


					<div id="D1"><!-- étudiant -->
						<label class="label">Centre :
							<select name="centre_list" class="centre_list">
								<?php foreach ($data_centre as $row): ?>
								    <option><?=$row["Centre"]?></option>
								<?php endforeach ?>
							</select></label>
						<label class="label">Promotion assignée :
							<select name="promo_list" class="promo_list">
								<?php foreach ($data_prom as $row): ?>
								    <option><?=$row["Nom"]?></option>
								<?php endforeach ?>
							</select></label>
					</div>
					<div id="D3"><!-- pilote -->
						<label class="label">Centre :
							<select name="centre_list" class="centre_list">
								<?php foreach ($data_centre as $row): ?>
								    <option><?=$row["Centre"]?></option>
								<?php endforeach ?>
							</select></label>
						<label class="label">Promotion assignée :
							<select name="promo_list" class="promo_list">
								<?php foreach ($data_prom as $row): ?>
								    <option><?=$row["Nom"]?></option>
								<?php endforeach ?>
							</select></label>
					</div>
					<!-- Envoyer -->
					<input type="submit" name="valider" value="Créer le compte" />
				</form>
			</div>
		</main>
		

		<?php if(!empty($message)){ ?>
			<div id="message"><?php echo $message ?></div>
		<?php } ?>

		
		<script type="text/javascript">
		// multiselect
			var expanded = false;

			function showCheckboxes() {
			  var checkboxes = document.getElementById("checkboxes");
			  if (!expanded) {
			    checkboxes.style.display = "block";
			    expanded = true;
			  } else {
			    checkboxes.style.display = "none";
			    expanded = false;
			  }
			}
		// radio select pour type de compte (hide et show les forms)
			function showRadio() {
				var n = document.fo.type_compte_r.length;

				for(i=1;i<=n;i++) {
					if(document.getElementById('choix'+i).checked == true) {
						document.getElementById('D'+i).style.display = "block";
					} else {
						document.getElementById('D'+i).style.display = "none";
					}
				}
			  }
		</script>

		<!-- Service Worker -->
		<script type="text/javascript">
			if('serviceWorker' in navigator){
			    navigator.serviceWorker.register('ServiceWorker.js') //Appelle du serviceWorker.js
			    .then( (sw) => console.log('Le Service Worker a été pris en charge', sw)) // si le SW s'est bien exécuté cela affichera ceci.
			    .catch((err) => console.log('Le Service Worker est introuvable', err)); // sinon il affichera ceci.
			}
		</script>
	</body>
</html>

