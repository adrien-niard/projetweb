//*************************************************************************//
//*************************************************************************//
//Dans ces deux variables on stock le nom de notre cache + l'assets qui contient les fichiers à garder en cache.
const NomDuCache= 'ma_sauvegarde';
const assets = [
    '/',
    '/index.php',
    '/inscription.php',
    '/connexion.php',
    '/deconnexion.php',
    '/main.php',
    '/entreprise/entreprise.php',
    '/offre/offre.php',
    '/manifest.json',
    '/css/style_index.css',
    '/css/style_inscription.css',
    '/assets/img/cesi.png'
];

//*************************************************************************//
//*************************************************************************//
//Installation du service worker
self.addEventListener('install', evt => {

     evt.waitUntil(  caches.open(NomDuCache).then(cache => {
        console.log('caching shell assets');
        cache.addAll(assets);
        })
    )
  
});

//*************************************************************************//
//*************************************************************************//
//Activation du Service Worker
self.addEventListener('activate', evt => {
    console.log('service Worker has been activated');
});

//*************************************************************************//
//*************************************************************************//
//fetch event afin de répondre quand on est en mode hors ligne.
self.addEventListener('fetch', function(event) {
    event.respondWith(
      caches.open('ma_sauvegarde').then(function(cache) {
        return cache.match(event.request).then(function (response) {
          return response || fetch(event.request).then(function(response) {
            cache.put(event.request, response.clone());
            return response;
          });
        });
      })
    );
  });
