<?php
	include("../connexion.php");

	// Data à envoyer dans la bdd (récupéré dans le form)
	@$secteur=$_POST["secteur"];
	@$confiance=$_POST["confiance"];
	@$nom=$_POST["nom"];
	@$adresse=$_POST["adresse"];
	//
	@$valider=$_POST["valider"];

	$message="";

	// Insertions dans la bdd
	if(isset($valider)){
		if(empty($secteur)) $message="<li>Secteur invalide !</li>";
		if(empty($confiance)) $message.="<li>Confiance invalide !</li>";
		if(empty($nom)) $message.="<li>Nom invalide !</li>";
		if(empty($adresse)) $message.="<li>Adresse invalides !</li>";

		$ins_in_entreprises=$pdo->prepare("INSERT INTO entreprises(Secteur,Confiance,Nom,Adresse,Nb_Stagiaires,Entreprise_visible) VALUES(?,?,?,?,0,1)");
		$ins_in_entreprises->execute(array($secteur,$confiance,$nom,$adresse));
		$up_in_entreprises=$pdo->query("UPDATE entreprises 
			SET Nb_Stagiaires = (SELECT Nb_Places FROM offres INNER JOIN entreprises ON offres.ID_Entreprise = entreprises.ID_Entreprise WHERE entreprises.ID_Entreprise = (SELECT MAX(ID_Entreprise) FROM entreprises)) 
			WHERE ID_Entreprise = (SELECT MAX(ID_Entreprise) FROM entreprises)");

		//header("location:index.php");
	}
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<link rel="stylesheet" type="text/css" href="style_entreprise.css" />
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="theme-color" content="#FFFF"/>
		<title>Création entreprise</title>
	</head>
	<body>
		<header>
			<div id="top_title">
				<img class="img-valign" src="cesi.png" height="80" alt="logo" />
				<span id="cesi">CESI</span><span id="ts"> ton stage!</span>
			</div>
		</header>
		<main>
			<div id="form_ins">
				<form name="fo" method="post" action="" enctype="multipart/form-data">
					<p id="f_p">Créer une entreprise</p>
					<div id="test">
						<label class="label">Nom :
							<input type="text" name="nom"/></label>
						<label class="label">Secteur d'activité :
							<input type="text" name="secteur"/></label>
						<label class="label">Adresse complète :
							<input type="text" name="adresse"/></label>
						<label class="label">Confiance du tuteur :
							<input type="text" name="confiance"/></label>
					</div>

					<!-- Envoyer -->
					<input type="submit" name="valider" value="Créer l'entreprise" />
				</form>
			</div>
		</main>
		

		<?php if(!empty($message)){ ?>
			<div id="message"><?php echo $message ?></div>
		<?php } ?>

	</body>
</html>

