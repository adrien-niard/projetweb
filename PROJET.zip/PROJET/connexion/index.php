<?php
	session_start();
	@$login=$_POST["login"];
	@$pass=$_POST["pass"];
	@$valider=$_POST["valider"];

	$message="";

	if(isset($valider)){
		include("../connexion.php");
		$res=$pdo->prepare("SELECT * FROM users WHERE Login=? AND Password=? LIMIT 1");
		$res->setFetchMode(PDO::FETCH_ASSOC);
		$res->execute(array($login,md5($pass)));
		$tab=$res->fetchAll();

		if(count($tab)==0)
			$message="<li>Mauvais login ou mot de passe!</li>";
		else{
			$_SESSION["autoriser"]="oui";
			$_SESSION["nomPrenom"]=strtoupper($tab[0]["Nom"]." ".$tab[0]["Prénom"]);
			header("location:main.php");
		}
	}
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<link rel="stylesheet" type="text/css" href="css/style_index.css" />
		<link rel="manifest" href="manifest.json">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="theme-color" content="#027DB4"/>
		<title>Connexion</title>
	</head>
	<body onLoad="document.fo.login.focus()">
		<header>
			<div id="top_title">
				<img class="img-valign" src="assets/img/cesi.png" height="80" alt="logo" />
				<span id="cesi">CESI</span><span id="ts"> ton stage!</span>
			</div>
		</header>
		<main>
			<div id="form_con">
				<p id="f_p">Connectez-vous à votre compte</p>
				<form name="fo" method="post" action="../accueil/accueil.html" class="lien">
					<label class="label">Email* :
					<input type="email" name="login" value="<?php echo $login?>"/></label>
					<label class="label">Mot de passe* :
					<input type="password" name="pass" /></label>
					<br>
					<input type="submit" name="valider" value="S'authentifier">
				</form>
				<p id="f_a">Si vous n'avez pas de compte, veuillez contacter un administrateur ou un tuteur de votre promotion.</p>
			</div>
		</main>

		<?php if(!empty($message)){ ?>
			<div id="message"><?php echo $message ?></div>
		<?php } ?>



		<!-- Service Worker -->
		<script type="text/javascript">
			if('serviceWorker' in navigator){
			    navigator.serviceWorker.register('ServiceWorker.js') //Appelle du serviceWorker.js
			    .then( (sw) => console.log('Le Service Worker a été pris en charge', sw)) // si le SW s'est bien exécuté cela affichera ceci.
			    .catch((err) => console.log('Le Service Worker est introuvable', err)); // sinon il affichera ceci.
			}
		</script>

		<script>
            $(".lien").click(function RedirectionJavascript(){
                $lien = this.getAttribute("lien");
                document.location.href = $lien + ".html"; 
            })
        </script>

	</body>
</html>