<?php
	include("../connexion.php");

	// Data à envoyer dans la bdd (récupéré dans le form)
	@$duree=$_POST["duree"];
	@$remun=$_POST["remun"];
	@$nb_places=$_POST["nb_p"];
	@$comp=$_POST["comp"];
	@$desc=$_POST["desc"];
	@$inti=$_POST["inti"];
	@$entrep=$_POST["entrep_list"];
	@$contrat=$_POST["contrat_list"];
	//
	@$valider=$_POST["valider"];

	$message="";

	// Listes déroulantes (centres et promotions)
	// Centres
	$smt_entrep = $pdo->prepare('SELECT Nom FROM entreprises');
	$smt_entrep->execute();
	@$data_entrep = $smt_entrep->fetchAll();
	// Promotions
	$smt_contrat = $pdo->prepare('SELECT Nom FROM type_contrat');
	$smt_contrat->execute();
	@$data_contrat = $smt_contrat->fetchAll();

	// Insertions dans la bdd
	if(isset($valider)){
		if(empty($duree)) $message="<li>Durée invalide !</li>";
		if(empty($remun)) $message.="<li>Rémunération invalide !</li>";
		if(empty($nb_places)) $message.="<li>Nombre de places invalide !</li>";
		if(empty($comp)) $message.="<li>Compétences invalides !</li>";
		if(empty($desc)) $message.="<li>Description invalide !</li>";
		if(empty($inti)) $message.="<li>Intitulé invalide !</li>";
		if(empty($entrep)) $message.="<li>Entreprise invalide !</li>";
		if(empty($contrat)) $message.="<li>Contrat invalide !</li>";

		$ins_in_offres=$pdo->prepare("INSERT INTO offres(ID_Entreprise,Durée,Rémunération,Date,Nb_Places,Compétences,Description,ID_Type_contrat,Intitulé,Offre_visible) VALUES(
			(SELECT ID_Entreprise FROM entreprises WHERE Nom = '$entrep'),?,?,now(),?,?,?,(SELECT ID_Type_contrat FROM type_contrat WHERE Nom = '$contrat'),?,1)");
		$ins_in_offres->execute(array($duree,$remun,$nb_places,$comp,$desc,$inti));

		$up_in_offres=$pdo->query("UPDATE offres 
			SET Places_restante = offres.Nb_Places 
			WHERE ID_Offre = (SELECT MAX(ID_Offre) FROM offres)");

		//header("location:index.php");
	}
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<link rel="stylesheet" type="text/css" href="style_offre.css" />
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="theme-color" content="#FFFF"/>
		<title>Création offre</title>
	</head>
	<body>
		<header>
			<div id="top_title">
				<img class="img-valign" src="cesi.png" height="80" alt="logo" />
				<span id="cesi">CESI</span><span id="ts"> ton stage!</span>
			</div>
		</header>
		<main>
			<div id="form_ins">
				<form name="fo" method="post" action="" enctype="multipart/form-data">
					<p id="f_p">Créer une offre</p>
					<div id="test">
						<label class="label">Intitulé du poste :
							<input type="text" name="inti"/></label>
						<label class="label">Durée du contrat (mois) :
							<input type="text" name="duree"/></label>
						<label class="label">Rémunération horaire (€/heure):
							<input type="text" name="remun"/></label>
						<label class="label">Nombre de places proposées :
							<input type="text" name="nb_p"/></label>
						<label class="label">Compétences requises :
							<input type="text" name="comp"/></label>
						<label class="label">Description de l'offre :
							<input type="text" name="desc"/></label>
						<label id="lab_e" class="label">Entreprise :<br>
							<select name="entrep_list" class="entrep_list">
								<?php foreach ($data_entrep as $row): ?>
								    <option><?=$row["Nom"]?></option>
								<?php endforeach ?>
							</select></label><br>
						<label id="lab_c" class="label">Type de contrat :<br>
							<select name="contrat_list" class="contrat_list">
								<?php foreach ($data_contrat as $row): ?>
								    <option><?=$row["Nom"]?></option>
								<?php endforeach ?>
							</select></label>
					</div>
					<!-- Envoyer -->
					<input type="submit" name="valider" value="Créer l'offre" />
				</form>
			</div>
		</main>
		

		<?php if(!empty($message)){ ?>
			<div id="message"><?php echo $message ?></div>
		<?php } ?>

	</body>
</html>

