<?php

    include("C:\www\Projet WEB\connexion.php");

    $rand_stage = $pdo->prepare('SELECT * FROM offres INNER JOIN entreprises ON offres.ID_Entreprise = entreprises.ID_Entreprise INNER JOIN type_contrat ON offres.ID_Type_contrat = type_contrat.ID_Type_contrat ORDER BY RAND() LIMIT 2');
    $rand_stage->execute();
    $res = $rand_stage->fetchAll();

?>


<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />

        <!-- Icone -->
        <link rel="icon" href=""/>

        <!-- CSS -->
        <link rel="stylesheet" type="text/css" href="accueil.css"/>

        <!-- Bootstrap -->
        <link rel="stylesheet" href="../assets/vendors/bootstrap/bootstrap-4.5.3-dist/css/bootstrap.min.css" />

        <!-- FontAwesome -->
        <link rel="stylesheet" href="../assets/vendors/fontawesome/css/all.min.css" />

        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Title -->
        <title>CESI ton stage</title>
    </head>
    <body>
        <!-- Header + Image + Bouton -->
        <header class="blog-header py-3 bg-dark">
            <div class="row flex-nowrap justify-content-between align-items-center">
                <div class="col-4 pt-1">
                    <!-- Logo CESI -->
                    <img src="../images/cesi.png" class="cesi" alt="Logo CESI Ton Stage" style="margin-left: 20px;"/>
                </div>
                <div class="col-4 text-center">
                    <!-- Titre de l'accueil : CESI ton stage -->
                    <a class="blog-header-title text-light" href="accueil.html">CESI ton stage</a>
                </div>
                <div class="col-4 d-flex justify-content-end align-items-center">
                    <!-- Bouton Pannel de contrôle -->
                    <a class="btn btn-md btn-outline-secondary" href="../panneau_de_gestion/panneau.html" style="margin: 0 20px 8px 0; color: white;">Pannel de contrôle</a>
                </div>
            </div>
        </header>
        <!-- Background de la recherche de stage-->
        <div class="hero-bg1 hero-overly">
            <!-- Recherche de stage -->
            <form class="stage-search">
                <div>
                    <div class="container py-5 d-flex justify-content-center">
                        <div class="form-row align-items-center">
                            <div class="col-auto">
                                <!-- Filtre Poste recherché -->
                                <label class="sr-only" for="inlineFormInput">Poste recherché</label>
                                <input type="text" class="form-control mb-2" id="inlineFormInput" placeholder="Poste recherché">

                            </div>
                            <div class="col-auto">
                                <!-- Filtre Lieu -->
                                <label class="sr-only" for="inlineFormInput">Lieu</label>
                                <input type="text" class="form-control mb-2" id="inlineFormInput" placeholder="Lieu">

                            </div>
                            <div class="col-auto">
                                <!-- Filtre Contrat -->
                                <label class="sr-only" for="inlineFormSelect">Contrat</label>
                                <select class="form-control mb-2" id="inlineFormSelect">
                                    <option selected>-- Contrat --</option>
                                    <option>CDI</option>
                                    <option>CDD</option>
                                    <option>Stage</option>
                                    <option>Alternance</option>
                                </select>

                            </div>
                            <div class="col-auto">
                                <!-- Bouton Submit -->
                                <button type="submit" class="btn btn-primary mb-2">Submit</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <!--2 stages mis en avant-->
            <section>
                <article class="row"> 
                    <div class="col-lg-1"></div>
                    <article class="col-lg-4">
                        <div class="card img-fluid lien" lien="article_1">
                            <img class="card-img-top" src="../images/pic-1.png" alt="Proposition stage 1">
                            <div class="card-img-overlay">
                                <h4 class="card-title"><?php echo $res[0][20]," ",$res[0][12]," - ",$res[0][2]," mois"; ?></h4>
                                <p class="card-text"><?php echo $res[0][4]; ?></p>
                                <a href="#" class="entreprise-btn btn btn-primary"><?php echo $res[0][15]; ?></a>
                            </div>
                        </div>
                    </article>
                    <div class="col-lg-2"></div>
                    <article class="col-lg-4">
                        <div class="card img-fluid lien" lien="article_2">
                            <img class="card-img-top" src="../images/pic-2.png" alt="Propostion stage 2">
                            <div class="card-img-overlay">
                                <h4 class="card-title"><?php echo $res[1][20]," ",$res[1][12]," - ",$res[1][2]," mois"; ?></h4>
                                <p class="card-text"><?php echo $res[1][4]; ?></p>
                                <a href="#" class="entreprise-btn btn btn-primary"><?php echo $res[1][15]; ?></a>
                            </div>
                        </div>
                    </article>
                    <div class="col-lg-1"></div>
                </article>
            </section>
        </div>
        <div class="container">
            <!--<div class="btn-group btn-group-toggle btn-block" data-toggle="buttons">
                <label class="btn btn-secondary">
                  <input type="radio" name="options" id="option1" autocomplete="off"> Agroalimentaire
                </label>
                <label class="btn btn-secondary">
                  <input type="radio" name="options" id="option2" autocomplete="off"> BTP
                </label>
                <label class="btn btn-secondary">
                  <input type="radio" name="options" id="option3" autocomplete="off"> Ressources Humaines
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="options" id="option3" autocomplete="off"> Communication
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="options" id="option3" autocomplete="off"> Informatique
                </label>
            </div>
            <div class="btn-group btn-group-toggle button-block" data-toggle="buttons">
                <label class="btn btn-secondary">
                  <input type="radio" name="options" id="option1" autocomplete="off"> Paris
                </label>
                <label class="btn btn-secondary">
                  <input type="radio" name="options" id="option2" autocomplete="off"> Lyon
                </label>
                <label class="btn btn-secondary">
                  <input type="radio" name="options" id="option3" autocomplete="off"> Toulouse
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="options" id="option3" autocomplete="off"> Rouen
                </label>
                <label class="btn btn-secondary">
                    <input type="radio" name="options" id="option3" autocomplete="off"> Lille
                </label>
            </div>-->
            <!--<div>
                <button type="button" class="btn btn-secondary">Agroalimentaire</button>
                <button type="button" class="btn btn-secondary">BTP</button>
                <button type="button" class="btn btn-secondary">Ressources Humaines</button>
                <button type="button" class="btn btn-secondary">Communication</button>
                <button type="button" class="btn btn-secondary">Informatique</button>
            </div>

            <div>
                <button type="button" class="btn btn-secondary">Paris</button>
                <button type="button" class="btn btn-secondary">Lyon</button>
                <button type="button" class="btn btn-secondary">Toulouse</button>
                <button type="button" class="btn btn-secondary">Rouen</button>
                <button type="button" class="btn btn-secondary">Lille</button>
            </div>-->
            <div class="jumbotron p-3" style="margin-top: 30px;">
                <h2>Les différents secteurs</h2>
                <div class="btn-group d-flex" style="margin-bottom: 10px;">
                    <button type="button" class="btn btn-secondary">Agroalimentaire</button>
                    <button type="button" class="btn btn-secondary">BTP</button>
                    <button type="button" class="btn btn-secondary">Ressources Humaines</button>
                    <button type="button" class="btn btn-secondary">Communication</button>
                    <button type="button" class="btn btn-secondary">Informatique</button>
                </div>
            </div>
            <div class="jumbotron p-3">
                <h2>Les différents lieux</h2>
                <div class="btn-group d-flex" style="margin-bottom: 10px;">
                    <button type="button" class="btn btn-secondary">Paris</button>
                    <button type="button" class="btn btn-secondary">Lyon</button>
                    <button type="button" class="btn btn-secondary">Toulouse</button>
                    <button type="button" class="btn btn-secondary">Rouen</button>
                    <button type="button" class="btn btn-secondary">Lille</button>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <footer class="bg-dark text-center text-white">
            <div class=" p-4 pb-0 d-flex justify-content-around">
                <div class="mb-4 pr-auto col-lg-4">
                    <h4>Nous contacter :</h4>
                    <p>sblondel@viacesi.fr</p>
                    <p>80 avenue Edmund Halley</p>
                    <p>76800, Saint-Étienne-du-Rouvray</p>
                </div>
                <section class="mb-4 d-flex align-self-center col-lg-4" style="padding-left: 13%;">
                    <!-- Facebook -->
                    <a class="btn btn-outline-light btn-floating m-1" href="https://fr-fr.facebook.com/CesiCampusRouen/" target="_blank" role="button">
                        <i class="fab fa-facebook-f"></i>
                    </a>
            
                    <!-- Twitter -->
                    <a class="btn btn-outline-light btn-floating m-1" href="https://twitter.com/GroupeCESI?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" target="_blank" role="button">
                        <i class="fab fa-twitter"></i>
                    </a>
            
                    <!-- Instagram -->
                    <a class="btn btn-outline-light btn-floating m-1" href="https://www.instagram.com/campus_cesi/?hl=fr" target="_blank" role="button">
                        <i class="fab fa-instagram"></i>
                    </a>
                </section>
              <div class="mb-4 pl-auto col-lg-4">
                <h4>Mentions légales :</h4>
                <p>...</p>
                <p>...</p>
                <p>...</p>
              </div>
            </div>
          
            <!-- Copyright -->
            <div class="text-center p-2" style="background-color: rgba(0, 0, 0, 0.2);">
              © 2021 Copyright:
              <a class="text-white" href="https://cesi.fr">CESI</a>
            </div>
        </footer>


        <!-- JQuery -->
        <script src="../assets/vendors/jquery/jquery-3.5.1.min.js"></script>

        <!-- Bootstrap -->
		<script src="../assets/vendors/bootstrap/bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"></script>  

        <!-- FontAwesome -->
        <script src="https://kit.fontawesome.com/fc47d2f2d9.js" crossorigin="anonymous"></script>
        
        <!-- Script pour cliquer sur les stages mis en avant -->
        <script>
            $(".lien").click(function RedirectionJavascript(){
                $lien = this.getAttribute("lien");
                document.location.href = $lien + ".html"; 
            })
        </script>
    </body>
</html>